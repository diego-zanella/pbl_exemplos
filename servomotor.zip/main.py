from machine import Pin, PWM
import dht
import time

DHT_PIN = 4  
SERVO_PIN = 12 

dht_sensor = dht.DHT22(Pin(DHT_PIN))

servo = PWM(Pin(SERVO_PIN), freq=50)  

def read_dht_data():
    dht_sensor.measure()
    temperature = dht_sensor.temperature()
    humidity = dht_sensor.humidity()
    return temperature, humidity

def set_servo_angle(angle):
    duty = int((angle / 180) * 1023) 
    servo.duty(duty)

def main():
    while True:
        temperature, humidity = read_dht_data()

        print("Temperatura: {:.1f} °C".format(temperature))
        print("Umidade: {:.1f}%".format(humidity))

        temperature_angle = int((temperature / 100) * 180) 
        set_servo_angle(temperature_angle)
        print("Servo Motor - Posição da Temperatura: {}°".format(temperature_angle))
        time.sleep(3)

        humidity_angle = int((humidity / 100) * 180) 
        set_servo_angle(humidity_angle)
        print("Servo Motor - Posição da Umidade: {}°".format(humidity_angle))
        time.sleep(3)

main()
