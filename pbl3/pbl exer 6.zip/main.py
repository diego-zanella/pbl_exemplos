import network
import time
from machine import Pin
from umqtt.simple import MQTTClient

led = Pin(2, Pin.OUT)  # Pin 2 is used for controlling the LED
button = Pin(4, Pin.IN)  # Pin 3 is used for the button input

# MQTT Server Parameters
MQTT_CLIENT_ID = "micropython-led-demo"
MQTT_BROKER = "broker.mqttdashboard.com"
MQTT_USER = "VISITANTES"
MQTT_PASSWORD = ""
MQTT_TOPIC = "led-status"

print("Connecting to WiFi", end="")
sta_if = network.WLAN(network.STA_IF)
sta_if.active(True)
sta_if.connect('Wokwi-GUEST', '')
while not sta_if.isconnected():
    print(".", end="")
    time.sleep(0.1)
print(" Connected!")

print("Connecting to MQTT server... ", end="")
client = MQTTClient(MQTT_CLIENT_ID, MQTT_BROKER, user=MQTT_USER, password=MQTT_PASSWORD)
client.connect()
print("Connected!")

def button_interrupt_handler(pin):
    led_state = "ON" if led.value() == 1 else "OFF"
    client.publish(MQTT_TOPIC, "LED state: {}".format(led_state))  # Publish LED state to MQTT topic

button.irq(trigger=Pin.IRQ_FALLING, handler=button_interrupt_handler)  # Set up interrupt on button pin

while True:
    led.on()  # Turn on the LED
    print("LED ON")
    time.sleep(5)  # Keep the LED on for 5 seconds

    led.off()  # Turn off the LED
    print("LED OFF")
    time.sleep(10)  # Keep the LED off for 10 seconds
