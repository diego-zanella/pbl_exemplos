import machine
import utime

# Define os pinos dos LEDs
led_red = machine.Pin(26, machine.Pin.OUT)
led_yellow = machine.Pin(25, machine.Pin.OUT)
led_green = machine.Pin(33, machine.Pin.OUT)

def handle_red_state():
    led_red.value(1)
    led_yellow.value(0)
    led_green.value(0)

def handle_yellow_state():
    led_red.value(0)
    led_yellow.value(1)
    led_green.value(0)

def handle_green_state():
    led_red.value(0)
    led_yellow.value(0)
    led_green.value(1)


def traffic_light():
    while True:
        # Estado 1: LED Vermelho (5 segundos)
        handle_red_state()
        utime.sleep(5)

        # Estado 2: LED Vermelho + Amarelo (1 segundo)
        handle_yellow_state()
        utime.sleep(1)

        # Estado 3: LED Verde (5 segundos)
        handle_green_state()
        utime.sleep(5)

# Executa a sequência do semáforo
traffic_light()
