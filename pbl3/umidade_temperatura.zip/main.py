
import dht
import machine
import time

DHT_PIN = 4

dht_sensor = dht.DHT22(machine.Pin(DHT_PIN))

def read_dht_data():
    dht_sensor.measure()
    temperature = dht_sensor.temperature()
    humidity = dht_sensor.humidity()
    return temperature, humidity

def main():
    while True:
        temperature, humidity = read_dht_data()
        
        if not temperature or not humidity:
            print("Falha ao ler dados do sensor DHT22")
        else:
            print("Temperatura: {:.1f} °C".format(temperature))
            print("Umidade: {:.1f} %".format(humidity))
        
        time.sleep(2)

main()
